/*
 * @Author: ELEGOO
 * @Date: 2019-07-10 16:46:17
 * @LastEditTime: 2020-08-26 10:47:28
 * @LastEditors: Changhua
 * @Description: OwlBot Car
 * @FilePath: 
 */

#ifndef _ApplicationFunctionSet_xxx0_H_
#define _ApplicationFunctionSet_xxx0_H_

#include <arduino.h>

class ApplicationFunctionSet
{
public:
  void ApplicationFunctionSet_Init(void);
  void ApplicationFunctionSet_Bootup(void);
  void ApplicationFunctionSet_RGB(void);
  void ApplicationFunctionSet_Expression(void);             //Expression Display
  void ApplicationFunctionSet_Rocker(void);                 //APP Rocker Control
  void ApplicationFunctionSet_Exploration(void);            //Exploration mode,unused
  void ApplicationFunctionSet_Tracking(void);               //Line Tracking Mode
  void ApplicationFunctionSet_Obstacle(void);               //Obstacle Avoidance
  void ApplicationFunctionSet_Standby(void);                //Standby Mode
  void ApplicationFunctionSet_KeyCommand(void);             //Mode Switch Button
  void ApplicationFunctionSet_SensorDataUpdate(void);       //Sensor Data Update
  void ApplicationFunctionSet_SerialPortDataAnalysis(void); //Serial Data Analysis

public: /*CMD*/
  void CMD_UltrasoundModuleStatus_xxx0(uint8_t is_get);
  void CMD_TraceModuleStatus_xxx0(uint8_t is_get);
  void CMD_Car_LeaveTheGround_xxx0(uint8_t is_get);
  void CMD_MotorControl_xxx0(void);
  void CMD_CarControlTimeLimit_xxx0(void);
  void CMD_CarControlNoTimeLimit_xxx0(void);
  void CMD_MotorControlSpeed_xxx0(void);
  void CMD_ServoControl_xxx0(void);
  void CMD_VoiceControl_xxx0(void);
  void CMD_LightingControlTimeLimit_xxx0(void);
  void CMD_LightingControlNoTimeLimit_xxx0(void);
  void CMD_LEDCustomExpressionControl_xxx0(void);
  void CMD_ClearAllFunctions_xxx0(void);
  void CMD_LEDNumberDisplayControl_xxx0(void);
  void CMD_TrajectoryControl_xxx0(void);

public:
  /*sensor value*/
  volatile float VoltageData_V;        //battery voltage value
  volatile uint16_t UltrasoundData_mm; //ultrasonic sensor value (mm)
  volatile uint16_t UltrasoundData_cm; //ultrasonic sensor value (cm)
  volatile uint16_t TrackingData_R;    //IR sensor value
  volatile uint16_t TrackingData_L;
  volatile uint16_t TrackingData_M;
  //volatile float mpu6050_Yaw; //Yaw value
public:
  /*sensor status*/
  boolean VoltageDetectionStatus = false;
  boolean UltrasoundDetectionStatus = false;
  boolean TrackingDetectionStatus_R = false;
  boolean TrackingDetectionStatus_L = false;
  boolean TrackingDetectionStatus_M = false;
  boolean Car_LeaveTheGround = true;

public:
  String CommandSerialNumber;
  uint8_t Rocker_CarSpeed = 255;

public: /*Threshold setting*/
#define VoltageDetection 3.70
#define ObstacleDetection 20

public: //Tracking
  uint16_t TrackingDetection_S = 200;
  uint16_t TrackingDetection_E = 860;
  uint16_t TrackingDetection_CarLeaveTheGround = 850;

public: //motor
  uint8_t CMD_is_MotorSelection;
  uint8_t CMD_is_MotorDirection;
  uint8_t CMD_is_MotorSpeed;
  uint32_t CMD_is_MotorTimer;
  uint8_t CMD_is_MotorSpeed_L;
  uint8_t CMD_is_MotorSpeed_R;
  uint8_t CMD_is_MotorSpeed_M;

public: //car
  uint8_t CMD_is_CarDirection;
  uint8_t CMD_is_CarSpeed;
  uint32_t CMD_is_CarTimer;

public: //voice
  uint8_t CMD_is_VoiceName;
  uint16_t CMD_is_controlAudio;
  uint32_t CMD_is_VoiceTimer;

public: //Lighting (Left, front, right, back and center)
  uint8_t CMD_is_LightingSequence;
  uint8_t CMD_is_LightingColorValue_R;
  uint8_t CMD_is_LightingColorValue_G;
  uint8_t CMD_is_LightingColorValue_B;
  uint32_t CMD_is_LightingTimer;

public: //LED Custom Expression Control
  uint8_t CMD_is_LEDCustomExpression_arry[16];
  uint8_t CMD_is_LEDNumber;

public: //Trajectory
  uint16_t CMD_is_TrajectoryControl_axisPlaneData_X;
  uint16_t CMD_is_TrajectoryControl_axisPlaneData_Y;

private: //LED
  uint8_t CMD_is_FastLED_setBrightness = 20;
};
extern ApplicationFunctionSet Application_FunctionSet;

#endif
