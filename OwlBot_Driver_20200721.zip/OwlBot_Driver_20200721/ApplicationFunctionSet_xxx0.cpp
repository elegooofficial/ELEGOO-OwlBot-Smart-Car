/*
 * @Author: ELEGOO
 * @Date: 2019-07-10 16:46:17
 * @LastEditTime: 2020-10-21 17:05:47
 * @LastEditors: Changhua
 * @Description: OwlBot Car
 * @FilePath: 
 */
#include <hardwareSerial.h>
#include <stdio.h>
#include <string.h>

#include "MsTimer2.h"
#include "ApplicationFunctionSet_xxx0.h"
#include "DeviceDriverSet_xxx0.h"
#include "TM1640.h"
#include "ArduinoJson-v6.11.1.h" //ArduinoJson
#include "MPU6050_getdata.h"
#define _is_print 1
#define _Test_print 0 //When testing, remember to set 0 after using the test to save controller resources and load.
ApplicationFunctionSet Application_FunctionSet;

/*Hardware device object list*/
MPU6050_getdata AppMPU6050getdata;
TM1640 Apptm1640;
DeviceDriverSet_RBGLED AppRBG_LED;
DeviceDriverSet_passiveBuzzer ApppassiveBuzzer;
DeviceDriverSet_Key AppKey;
DeviceDriverSet_Voltage AppVoltage;
DeviceDriverSet_Motor AppMotor;
DeviceDriverSet_ULTRASONIC AppULTRASONIC;
DeviceDriverSet_STM8S003F3_IR AppSTM8S003F3_IR;

/*f(x) int */
static boolean
function_xxx(long x, long s, long e) //f(x)
{
  if (s <= x && x <= e)
    return true;
  else
    return false;
}

/*Movement Direction Control List*/
enum OwlBotMotionControl
{
  Forward,       //(1)
  Backward,      //(2)
  Left,          //(3)
  Right,         //(4)
  LeftForward,   //(5)
  LeftBackward,  //(6)
  RightForward,  //(7)
  RightBackward, //(8)
  stop_it        //(9)
};               //

/*Mode Control List*/
enum OwlBotFunctionalModel
{
  Standby_mode,           /*Standby Mode*/
  TraceBased_mode,        /*Line Tracking Mode*/
  ObstacleAvoidance_mode, /*Obstacle Avoidance Mode*/
  Rocker_mode,            /*Rocker Control Mode*/
  Exploration_mode,

  CMD_Programming_mode,                   /*Programming Mode*/
  CMD_ClearAllFunctions_Standby_mode,     /*Clear All Functions And Enter Standby Mode*/
  CMD_ClearAllFunctions_Programming_mode, /*Clear All Functions And Enter Programming Mode*/
  CMD_MotorControl,                       /*Motor Control Mode*/
  CMD_CarControl_TimeLimit,               /*Car Movement Direction Control With Time Limit*/
  CMD_CarControl_NoTimeLimit,             /*Car Movement Direction Control Without Time Limit*/
  CMD_MotorControl_Speed,                 /*Motor Speed Control*/
  CMD_ServoControl,                       /*Servo Control Mode*/
  CMD_VoiceControl,                       /*Voice Control Mode*/
  CMD_ledExpressionControl,               /*Led Expression Control Mode*/
  CMD_ledNumberControl,                   /*Led Number Control Mode*/
  CMD_LightingControl_TimeLimit,          /*RGB Lighting Control With Time Limit*/
  CMD_LightingControl_NoTimeLimit,        /*RGB Lighting Control Without Time Limit*/
  CMD_TrajectoryControl,                  /*Trajectory Control Mode*/
};

/*Application Management list*/
struct Application_xxx
{
  OwlBotMotionControl Motion_Control;
  OwlBotFunctionalModel Functional_Mode;
  unsigned long CMD_CarControl_Millis;
  unsigned long CMD_LightingControl_Millis;
  float AppMPU6050getdata_yaw;
};
Application_xxx Application_OwlBotxxx0;
static bool ApplicationFunctionSet_OwlBotLeaveTheGround(void);
static void ApplicationFunctionSet_MetalCarLinearMotionControl(OwlBotMotionControl direction, uint8_t directionRecord, uint8_t speed, uint8_t Kp, uint8_t UpperLimit);
static void ApplicationFunctionSet_OwlBotMotionControl(OwlBotMotionControl direction, uint8_t speed);

void ApplicationFunctionSet::ApplicationFunctionSet_Init(void)
{
  bool res_error = true;
  Serial.begin(9600);
  AppSTM8S003F3_IR.DeviceDriverSet_STM8S003F3_IR_Init();
  Apptm1640.TM1640_InitConfig_led16x8(true);
  AppRBG_LED.DeviceDriverSet_RBGLED_Init(20 /*set Brightness*/);
  ApppassiveBuzzer.DeviceDriverSet_passiveBuzzer_Init();
  AppKey.DeviceDriverSet_Key_Init();
  AppMotor.DeviceDriverSet_Motor_Init();
  AppULTRASONIC.DeviceDriverSet_ULTRASONIC_Init();
  res_error = AppMPU6050getdata.MPU6050_dveInit();
  AppMPU6050getdata.MPU6050_calibration();
  while (Serial.read() >= 0)
  {
    /*Clear serial port buffer...*/
  }
}

static bool ApplicationFunctionSet_OwlBotLeaveTheGround(void)
{
  /*value updation for the STM8S003F3 IR sensor：for the line tracking mode*/
  AppSTM8S003F3_IR.DeviceDriverSet_STM8S003F3_IR_Get(&Application_FunctionSet.TrackingData_L /*uint16_t * STM8S003F3_IRL out*/,
                                                     &Application_FunctionSet.TrackingData_M /*uint16_t * STM8S003F3_IRM out*/,
                                                     &Application_FunctionSet.TrackingData_R /*uint16_t * STM8S003F3_IRR out*/);

  /*update left IR sensor value*/
  Application_FunctionSet.TrackingDetectionStatus_R = function_xxx(Application_FunctionSet.TrackingData_R, Application_FunctionSet.TrackingDetection_S, Application_FunctionSet.TrackingDetection_E);
  /*update middle IR sensor value*/
  Application_FunctionSet.TrackingDetectionStatus_M = function_xxx(Application_FunctionSet.TrackingData_M, Application_FunctionSet.TrackingDetection_S, Application_FunctionSet.TrackingDetection_E);
  /*update right IR sensor value*/
  Application_FunctionSet.TrackingDetectionStatus_L = function_xxx(Application_FunctionSet.TrackingData_L, Application_FunctionSet.TrackingDetection_S, Application_FunctionSet.TrackingDetection_E);
  //Check if the car is lifted up
  if (Application_FunctionSet.TrackingData_L > Application_FunctionSet.TrackingDetection_CarLeaveTheGround &&
      Application_FunctionSet.TrackingData_M > Application_FunctionSet.TrackingDetection_CarLeaveTheGround &&
      Application_FunctionSet.TrackingData_R > Application_FunctionSet.TrackingDetection_CarLeaveTheGround)
  {
    Application_FunctionSet.Car_LeaveTheGround = false;
    return false;
  }
  else
  {
    Application_FunctionSet.Car_LeaveTheGround = true;
    return true;
  }
}

/*
  Straight line movement control：For dual-drive motors, due to frequent motor coefficient deviations and many external interference factors, 
  it is difficult for the car to achieve relative Straight line movement. For this reason, the feedback of the yaw control loop is added.
  direction：only forward/backward
  directionRecord：Used to update the direction and position data (Yaw value) when entering the function for the first time.
  speed：the speed range is 0~250
  Kp：Position error proportional constant（The feedback of improving location resuming status，will be modified according to different mode），improve damping control.
  UpperLimit：Maximum output upper limit control
*/
static void
ApplicationFunctionSet_MetalCarLinearMotionControl(OwlBotMotionControl direction, uint8_t directionRecord, uint8_t speed, uint8_t Kp, uint8_t UpperLimit)
{
  static float Yaw; 
  static float yaw_So = 0;
  static uint8_t en = 0;
  //acquire timestamp
  static unsigned long is_time;
  if (en != directionRecord || millis() - is_time > 10)
  {
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_void, /*speed_A*/ 0, /*direction_B*/ direction_void, /*speed_B*/ 0, /*controlED*/ control_enable); //Motor control
    AppMPU6050getdata.MPU6050_dveGetEulerAngles(&Yaw);
    is_time = millis();
  }

  //if (en != directionRecord) ///Record the yaw position value for the first time
  if (en != directionRecord || Application_FunctionSet.Car_LeaveTheGround == false)
  {
    en = directionRecord;
    yaw_So = Yaw;
  }
  //Add proportional constant Kp to increase rebound effect
  //Right motor speed value
  int R = (Yaw - yaw_So) * Kp + speed;
  if (R > UpperLimit)
  {
    R = UpperLimit;
  }
  else if (R < 10)
  {
    R = 10;
  }
  //Left motor speed value
  int L = (yaw_So - Yaw) * Kp + speed;
  if (L > UpperLimit)
  {
    L = UpperLimit;
  }
  else if (L < 10)
  {
    L = 10;
  }

  if (direction == Forward) //Forward
  {
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ R,
                                           /*direction_B*/ direction_just, /*speed_B*/ L, /*controlED*/ control_enable);
  }
  else if (direction == Backward) //Backward
  {
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ L,
                                           /*direction_B*/ direction_back, /*speed_B*/ R, /*controlED*/ control_enable);
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   static void ApplicationFunctionSet_OwlBotMotionControl(OwlBotMotionControl direction, uint8_t speed)
@ Functional function:  Owl Car Movement Direction Control
@ Input parameters:     1# direction:Forward（1）、Backward（2）、 Left（3）、Right（4）、LeftForward（5）、LeftBackward（6）、RightForward（7）RightBackward（8）
                        2# speed(0--255)
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer static function<Call the hardware driver layer DeviceDriverSet_xxx0  use Motor_control interface to achieve>
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
static void
ApplicationFunctionSet_OwlBotMotionControl(OwlBotMotionControl direction, uint8_t speed)
{
  ApplicationFunctionSet Application_FunctionSet;
  static uint8_t directionRecord = 0;
  uint8_t Kp, UpperLimit;
  //Control mode that requires straight line movement adjustment（Car will has movement offset easily in the below mode，the movement cannot achieve the effect of a relatively straight direction
  //so it needs to add control adjustment）
  switch (Application_OwlBotxxx0.Functional_Mode)
  {
  case Rocker_mode:
    Kp = 10;
    UpperLimit = 250;
    break;
  case ObstacleAvoidance_mode:
    Kp = 2;
    UpperLimit = 255;
    //UpperLimit = 180;
    break;
  case CMD_CarControl_TimeLimit:
    Kp = 2;
    UpperLimit = 255;
    //UpperLimit = 180;
    break;
  case CMD_CarControl_NoTimeLimit:
    Kp = 2;
    UpperLimit = 255;
    //UpperLimit = 180;
    break;
  default:
    break;
  }
  switch (direction)
  {
  case /* constant-expression */
      Forward:
    /* code */
    //if (Application_OwlBotxxx0.Functional_Mode == TraceBased_mode)
    if (Application_OwlBotxxx0.Functional_Mode == TraceBased_mode || Application_OwlBotxxx0.Functional_Mode == CMD_TrajectoryControl)
    {
      AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ speed,
                                             /*direction_B*/ direction_just, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    }
    else
    { //When moving forward, enter the direction and position approach control loop processing

      ApplicationFunctionSet_MetalCarLinearMotionControl(Forward, directionRecord, speed, Kp, UpperLimit);
      directionRecord = 1;
    }

    break;
  case /* constant-expression */ Backward:
    /* code */
    if (Application_OwlBotxxx0.Functional_Mode == TraceBased_mode || Application_OwlBotxxx0.Functional_Mode == CMD_TrajectoryControl)
    //if (Application_OwlBotxxx0.Functional_Mode == TraceBased_mode)
    {
      AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ speed,
                                             /*direction_B*/ direction_back, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    }
    else
    { //When moving backward, enter the direction and position approach control loop processing
      ApplicationFunctionSet_MetalCarLinearMotionControl(Backward, directionRecord, speed, Kp, UpperLimit);
      directionRecord = 2;
    }

    break;
  case /* constant-expression */ Left:
    /* code */
    directionRecord = 3;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ speed,
                                           /*direction_B*/ direction_back, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    break;
  case /* constant-expression */ Right:
    /* code */
    directionRecord = 4;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ speed,
                                           /*direction_B*/ direction_just, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    break;
  case /* constant-expression */ LeftForward:
    /* code */
    directionRecord = 5;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ speed,
                                           /*direction_B*/ direction_just, /*speed_B*/ speed - 130, /*controlED*/ control_enable); //Motor control

    break;
  case /* constant-expression */ LeftBackward:
    /* code */
    directionRecord = 6;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ speed,
                                           /*direction_B*/ direction_back, /*speed_B*/ speed - 130, /*controlED*/ control_enable); //Motor control
    break;
  case /* constant-expression */ RightForward:
    /* code */
    directionRecord = 7;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ speed - 130,
                                           /*direction_B*/ direction_just, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    break;
  case /* constant-expression */ RightBackward:
    /* code */
    directionRecord = 8;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ speed - 130,
                                           /*direction_B*/ direction_back, /*speed_B*/ speed, /*controlED*/ control_enable); //Motor control
    break;
  case /* constant-expression */ stop_it:
    /* code */
    directionRecord = 9;
    AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_void, /*speed_A*/ 0,
                                           /*direction_B*/ direction_void, /*speed_B*/ 0, /*controlED*/ control_enable); //Motor control
    break;
  default:
    directionRecord = 8;
    break;
  }
}
// /*WaveFiltering:*/
// static void WaveFiltering(uint8_t A_n, uint8_t *out)
// {
//   static uint8_t Record[4];
//   uint8_t cout = 0;
//   static uint8_t Record_out;

//   if (abs(A_n - Record[3]) < 5)
//   {
//     cout += 1;
//   }
//   if (abs(A_n - Record[2]) < 5)
//   {
//     cout += 1;
//   }
//   if (abs(A_n - Record[1]) < 5)
//   {
//     cout += 1;
//   }
//   if (abs(A_n - Record[0]) < 5)
//   {
//     cout += 1;
//   }
//   Record[4] = A_n;

//   for (uint8_t n = 0; n < 5; n++)
//   {
//     Record[n] = Record[n + 1];
//   }
//   if (cout == 4)
//   {
//     *out = A_n;
//     Record_out = A_n;
//   }
//   else
//   {
//     *out = Record_out;
//   }
// }

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_SensorDataUpdate(void)
@ Functional function:  Owl Car update sensors' data
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function<Call the hardware driver layer DeviceDriverSet_xxx0>
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_SensorDataUpdate(void)
{

  { /*value updation for the ultrasonic sensor：for the Obstacle Avoidance mode*/
    AppULTRASONIC.DeviceDriverSet_ULTRASONIC_Get(&UltrasoundData_mm /*out*/);
    UltrasoundData_cm = UltrasoundData_mm / 10;
    UltrasoundDetectionStatus = function_xxx(UltrasoundData_cm, 0, ObstacleDetection); //Obstacle Avoidance status
  }
  /*value updation for the STM8S003F3 IR sensor：for the line tracking mode*/
  ApplicationFunctionSet_OwlBotLeaveTheGround();

  { /*Battery voltage status update*/
    static unsigned long VoltageData_time = 0;
    static int VoltageData_number = 1;
    if (millis() - VoltageData_time > 10) //read and update the data per 10ms
    {
      VoltageData_time = millis();
      VoltageData_V = AppVoltage.DeviceDriverSet_Voltage_getAnalogue();

      if ((VoltageData_V > 5.5 && VoltageData_V < 7.0) || (VoltageData_V > 2.0 && VoltageData_V < 3.7)) //Dual battery detection compatible
      // if (VoltageData_V < VoltageDetection)
      {
        VoltageData_number++;
        if (VoltageData_number == 1000) //Continuity to judge the latest voltage value multiple times...
        {
          VoltageDetectionStatus = true;
          VoltageData_number = 0;
        }
      }
      else
      {
        VoltageDetectionStatus = false;
      }
    }
  }
  //acquire timestamp
  // static unsigned long Test_time;
  // if (millis() - Test_time > 10)
  // {
  //   Test_time = millis();
  //   AppMPU6050getdata.MPU6050_dveGetEulerAngles();
  // }
}

// static void MsTimer2_updata(void)
// {
//   sei();
// }

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Bootup(void)
@ Functional function:  Owl Car boot action settings
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This ia an ApplicationFunctionSet layer public function<Call the hardware driver layer <DeviceDriverSet_xxx0_H /TM1640.h>
  1# Expression panel display
  2# Active buzzer plays C scale (plays eight notes)
  3# Owl Car enter standby mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Bootup(void)
{
  Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[6] /*in*/);
  ApppassiveBuzzer.DeviceDriverSet_passiveBuzzer_Scale_c8(100 /*in:Duration*/);
  Application_OwlBotxxx0.Functional_Mode = Standby_mode;
  // MsTimer2::set(100, MsTimer2_updata);
  // MsTimer2::start();
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_RGB(void)
@ Functional function:  Owl Car RBG_LED display collection
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This ia an ApplicationFunctionSet layer public function<Call the hardware driver layer DeviceDriverSet_xxx0_H>
  1# Act on low power state
  2# Act on mode control
  This is a set of RGB display logic control sets
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_RGB(void)
{
  static boolean ED = false;
  static unsigned long getAnalogue_time = 0;
  FastLED.clear(true);

  if (true == VoltageDetectionStatus) //1# Act on low power state？
  {
    if (ED == false)
    {
      getAnalogue_time = millis();
      ED = true;
    }
    if ((millis() - getAnalogue_time) < 50)
    {
      AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Red);
    }
    else if ((millis() - getAnalogue_time) < 100)
    {
      AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Black);
      getAnalogue_time = millis();
    }
  }
  else
  {
    ED = false;
    switch (Application_OwlBotxxx0.Functional_Mode) //2# Act on mode control
    {
    case /* constant-expression */ Standby_mode:
      /* code */
      {
        if (VoltageDetectionStatus == true)
        {
          AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Red);
          delay(30);
          AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Black);
          delay(30);
        }
        else
        { //Used for breathing light effect
          static uint8_t setBrightness = 0;
          static uint8_t colour = 0;
          static boolean et = false;
          static unsigned long time = 0;

          if ((millis() - time) > 30)
          {
            time = millis();
            if (et == false)
            {
              setBrightness += 1;
              if (setBrightness == 80)
                et = true;
            }
            else if (et == true)
            {
              setBrightness -= 1;
              if (setBrightness == 1)
              {
                et = false;
                colour = rand() % (8 - 0) + 0; //Generate a random number <0--8> for irregular color selection
              }
            }
          }
          if (colour == 0)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Brown;
          }
          else if (colour == 1)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Red;
          }
          else if (colour == 2)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Orange;
          }
          else if (colour == 3)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Yellow;
          }
          else if (colour == 4)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Green;
          }
          else if (colour == 5)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Blue;
          }
          else if (colour == 6)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Purple;
          }
          else if (colour == 7)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::Violet;
          }
          else if (colour == 8)
          {
            for (int i = 0; i < 5; i++)
              AppRBG_LED.leds[i] = CRGB::White;
          }

          FastLED.setBrightness(setBrightness);
          FastLED.show();
        }
      }
      break;
    case /* constant-expression */ CMD_Programming_mode:
      /* code */
      {
      }
      break;
    case /* constant-expression */ TraceBased_mode:
      /* code */
      {
        AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Green);
      }
      break;
    case /* constant-expression */ ObstacleAvoidance_mode:
      /* code */
      {
        AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Yellow);
      }
      break;
    case /* constant-expression */ Rocker_mode:
      /* code */
      {
        switch (Application_OwlBotxxx0.Motion_Control)
        {
        case /* constant-expression */ Forward:
          /* code */
          {
            AppRBG_LED.leds[2] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ Backward:
          /* code */
          {
            AppRBG_LED.leds[0] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ Left:
          /* code */
          {
            AppRBG_LED.leds[3] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ Right:
          /* code */
          {
            AppRBG_LED.leds[1] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ LeftForward:
          /* code */
          {
            AppRBG_LED.leds[2] = CRGB::Blue;
            AppRBG_LED.leds[3] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ LeftBackward:
          /* code */
          {
            AppRBG_LED.leds[0] = CRGB::Blue;
            AppRBG_LED.leds[3] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ RightForward:
          /* code */
          {
            AppRBG_LED.leds[2] = CRGB::Blue;
            AppRBG_LED.leds[1] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ RightBackward:
          /* code */
          {
            AppRBG_LED.leds[1] = CRGB::Blue;
            AppRBG_LED.leds[0] = CRGB::Blue;
            FastLED.show();
          }
          break;
        case /* constant-expression */ stop_it:
          /* code */
          {
            AppRBG_LED.leds[4] = CRGB::White;
            FastLED.show();
            delay(30);
            AppRBG_LED.leds[3] = CRGB::Yellow;
            FastLED.show();
            delay(30);
            AppRBG_LED.leds[2] = CRGB::Green;
            FastLED.show();
            delay(30);
            AppRBG_LED.leds[1] = CRGB::Red;
            FastLED.show();
            delay(30);
            AppRBG_LED.leds[0] = CRGB::Orange;
            FastLED.show();
            delay(30);
            AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Black);
          }
          break;
        default:
          break;
        }
      }
      break;
    default:
      break;
    }
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Expression(void)
@ Functional function:  Owl Car expression panel display collection
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function<Call the hardware driver layer TM1640.h>
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Expression(void)
{
  switch (Application_OwlBotxxx0.Functional_Mode) //Act on mode control sequence
  {
  case /* constant-expression */ Standby_mode: //In Standby mode mode, the panel will cyclically display the expression logo set at 1000ms intervals

    /* code */
    {
      static unsigned long Standby_mode_time = 0;
      static uint8_t Standby_mode_Panel = 0;
      if (millis() - Standby_mode_time > 1000)
      {
        Standby_mode_time = millis();
        Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[Standby_mode_Panel] /*in*/);
        Standby_mode_Panel += 1;
        if (Standby_mode_Panel > 9)
        {
          Standby_mode_Panel = 0;
        }
      }
    }
    break;
  case /* constant-expression */ CMD_ledExpressionControl:
    break;
  case /* constant-expression */ CMD_ledNumberControl:
    break;
  case /* constant-expression */ TraceBased_mode:
    /* code */
    {
      if (true == TrackingDetectionStatus_R && true == TrackingDetectionStatus_L)
      {
        Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[8] /*in*/);
      }
      else
      {
        Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[2] /*in*/);
      }
    }
    break;
  case /* constant-expression */ ObstacleAvoidance_mode:
    /* code */
    {
      if (true == UltrasoundDetectionStatus)
      {
        Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[0] /*in*/);
      }
      else
      {
        Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[4] /*in*/);
      }
    }
    break;
  case /* constant-expression */ Rocker_mode:
    /* code */
    {
      static unsigned long Rocker_mode_time = 0;
      static boolean Rocker_mode_Panel = false;
      if (millis() - Rocker_mode_time > 100)
      {
        Rocker_mode_time = millis();
        if (false == Rocker_mode_Panel)
        {
          Rocker_mode_Panel = true;
          Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[0] /*in*/);
        }
        else
        {
          Rocker_mode_Panel = false;
          Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[9] /*in*/);
        }
      }
      switch (Application_OwlBotxxx0.Motion_Control)
      {
      case /* constant-expression */ stop_it:
        /* code */
        {
          static unsigned long stop_it_time = 0;
          static uint8_t stop_it_Panel = 0;
          if (millis() - stop_it_time > 1000)
          {
            stop_it_time = millis();
            Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Model[stop_it_Panel] /*in*/);
            stop_it_Panel += 1;
            if (stop_it_Panel > 9)
              stop_it_Panel = 0;
          }
        }
        break;
      default:
        break;
      }
    }
    break;
  default:
    break;
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Rocker(void)
@ Functional function:  Owl Car Rocker control mode
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function<Call ApplicationFunctionSet_OwlBotMotionControl()>
  Command N102:APP rocker control mode(Command reception and analysis implementation：ApplicationFunctionSet_SerialPortDataAnalysis())
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Rocker(void)
{

  if (Application_OwlBotxxx0.Functional_Mode == Rocker_mode)
  {
    ApplicationFunctionSet_OwlBotMotionControl(Application_OwlBotxxx0.Motion_Control /*direction*/, 255 /*speed*/);
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Exploration(void)
@ Functional function:  Owl Car exploration mode (Note:exploration mode is disabled on the owlbot)
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function<Call ApplicationFunctionSet_OwlBotMotionControl()>
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Exploration(void)
{
  // if (Application_OwlBotxxx0.Functional_Mode == Exploration_mode)
  // {
  //   float getAnaloguexxx_R = AppITR20001.DeviceDriverSet_ITR20001_getAnaloguexxx_R(); //acquire ITR20001 sensor value
  //   float getAnaloguexxx_L = AppITR20001.DeviceDriverSet_ITR20001_getAnaloguexxx_L();
  //   if ((getAnaloguexxx_R > TrackingDetection_CarLeaveTheGround) || (getAnaloguexxx_L > TrackingDetection_CarLeaveTheGround))
  //   {
  //     /*robot car move backward*/
  //     ApplicationFunctionSet_OwlBotMotionControl(Backward, 150);
  //     delay(500);
  //     /*robot car move left*/
  //     ApplicationFunctionSet_OwlBotMotionControl(Left, 100);
  //     delay(800);
  //   }
  //   else
  //   {
  //     /*robot car move forward*/
  //     ApplicationFunctionSet_OwlBotMotionControl(Forward, 100);
  //   }
  // }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Tracking(void)
@ Functional function:  Owl Car line tracking mode
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function
  mode entry conditions：ApplicationFunctionSet_KeyCommand():1 / ApplicationFunctionSet_SerialPortDataAnalysis()：N 101
  1#Can switch to this mode through app commands and mode switch button
  2#Obtain three analog IR sensors' data（range:0--1024）
  3#Threshold range（range on the black line：200 -- 860）
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 Line tracking mode code table：2E3=8（Combination of three sensors to program 8 states）
 --------------------------------|
  L/   0  1  0  1  0  1  0  1    |
 --------------------------------|
  M/   0  0  1  1  0  0  1  1    |
 --------------------------------|
  R/   0  0  0  0  1  1  1  1    |
 --------------------------------|
       0  1  2  3  4  5  6  7    |
 --------------------------------|
 Forward：2、7     /    Turn left：1、3     /     Turn right：4、6      /      Blind scan：0
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Tracking(void)
{
  static boolean timestamp = true;
  static boolean BlindDetection = true;
  static unsigned long MotorRL_time = 0;
  static uint8_t DirectionRecording = 0;

  if (Application_OwlBotxxx0.Functional_Mode == TraceBased_mode)
  {
    if (Car_LeaveTheGround == false)
    {
      ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      return;
    }

    AppSTM8S003F3_IR.DeviceDriverSet_STM8S003F3_IR_Get(&TrackingData_L /*uint16_t * STM8S003F3_IRL out*/,
                                                       &TrackingData_M /*uint16_t * STM8S003F3_IRM out*/,
                                                       &TrackingData_R /*uint16_t * STM8S003F3_IRR out*/);

#if _Test_print
    static unsigned long print_time = 0;
    if (millis() - print_time > 500)
    {
      print_time = millis();
      Serial.print("TrackingData_L=");
      Serial.println(TrackingData_L);
      Serial.print("TrackingData_M=");
      Serial.println(TrackingData_M);
      Serial.print("TrackingData_R=");
      Serial.println(TrackingData_R);
    }
#endif

    if (1 == function_xxx(TrackingData_M, TrackingDetection_S, TrackingDetection_E)) //Forward 2==010
    {
      timestamp = true;
      BlindDetection = true;
      /*Achieve straight and uniform speed movement*/
      ApplicationFunctionSet_OwlBotMotionControl(Forward, 200);
      DirectionRecording = 0;
    }
    else if (1 == function_xxx(TrackingData_L, TrackingDetection_S, TrackingDetection_E) &&
             // 0 == function_xxx(TrackingData_M, TrackingDetection_S, TrackingDetection_E) &&
             0 == function_xxx(TrackingData_R, TrackingDetection_S, TrackingDetection_E)) //Turn left 1==001 || 3==011  
    {
      timestamp = true;
      BlindDetection = true;
      /*Turn left*/
      ApplicationFunctionSet_OwlBotMotionControl(Left, 200);
      DirectionRecording = 1;
    }
    else if (0 == function_xxx(TrackingData_L, TrackingDetection_S, TrackingDetection_E) &&
             // 0 == function_xxx(TrackingData_M, TrackingDetection_S, TrackingDetection_E) &&
             1 == function_xxx(TrackingData_R, TrackingDetection_S, TrackingDetection_E)) //Turn right 4==100 || 6==110  
    {
      timestamp = true;
      BlindDetection = true;
      /*Turn right*/
      ApplicationFunctionSet_OwlBotMotionControl(Right, 200);
      DirectionRecording = 2;
    }
    else //The car is not on the black line. execute Blind scan   0==0000
    {

      ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      //acquire timestamp
      if (timestamp == true)
      {
        timestamp = false;
        MotorRL_time = millis();
        ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      }
      /*Blind Detection*/
      if ((function_xxx((millis() - MotorRL_time), 0, 200) || function_xxx((millis() - MotorRL_time), 600, 1000) || function_xxx((millis() - MotorRL_time), 1500, 3600)) && BlindDetection == true)
      {
        if (1 == DirectionRecording)
        {
          ApplicationFunctionSet_OwlBotMotionControl(Right, 150);
        }
        else
        {
          ApplicationFunctionSet_OwlBotMotionControl(Left, 150);
        }
      }
      else if (((function_xxx((millis() - MotorRL_time), 200, 600)) || function_xxx((millis() - MotorRL_time), 1000, 1400)) && BlindDetection == true)
      {
        if (1 == DirectionRecording)
        {
          ApplicationFunctionSet_OwlBotMotionControl(Left, 150);
        }
        else
        {
          ApplicationFunctionSet_OwlBotMotionControl(Right, 150);
        }
      }
      else if (((function_xxx((millis() - MotorRL_time), 1400, 1500))) && BlindDetection == true)
      {
        ApplicationFunctionSet_OwlBotMotionControl(Forward, 150);
      }
      else if ((function_xxx((millis() - MotorRL_time), 5000, 5500))) // Blind Detection ...s ?
      {
        BlindDetection == false;
        ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      }
    }
  }
  else
  {
    timestamp = true;
    BlindDetection = true;
    MotorRL_time = 0;
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_Obstacle(void)
@ Functional function:  Owl Car Obstacle Avoidance Mode
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function
  mode entry conditions：ApplicationFunctionSet_KeyCommand():2 / ApplicationFunctionSet_SerialPortDataAnalysis()：N 101
  1#Can switch to this mode through app commands and mode switch button
  2#Obtain ultrasonic sensor's distance value
  3#Set distance threshold（30cm）
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_Obstacle(void)
{
  static boolean timestamp = true;
  if (Application_OwlBotxxx0.Functional_Mode == ObstacleAvoidance_mode)
  {
    if (Car_LeaveTheGround == false) //Check if car is lifted up
    {
      ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      return;
    }
    if (function_xxx(UltrasoundData_cm, 0, ObstacleDetection)) //Is there an obstacle in xx cm ahead?(Ultrasonic ranging data is updated periodically in the background)
    {
      //acquire timestamp
      static unsigned long MotorRL_time;
      // if (timestamp == true || millis() - MotorRL_time > 2500)
      if (timestamp == true || millis() - MotorRL_time > 4000)
      {
        timestamp = false;
        MotorRL_time = millis();
      }

      if (function_xxx((millis() - MotorRL_time), 0, 800) || function_xxx((millis() - MotorRL_time), 3200, 4000))
      {
        /*turn left*/
        ApplicationFunctionSet_OwlBotMotionControl(Left, 200);
      }
      else if (function_xxx((millis() - MotorRL_time), 800, 2400))
      {
        /*turn right*/
        ApplicationFunctionSet_OwlBotMotionControl(Right, 200);
      }
      else if (function_xxx((millis() - MotorRL_time), 2400, 3200))
      {
        /*move backward*/
        ApplicationFunctionSet_OwlBotMotionControl(Backward, 255);
      }
    }
    else
    {
      timestamp = true;
      /*Achieve straight and uniform speed movement*/
      ApplicationFunctionSet_OwlBotMotionControl(Forward, 180);
    }
  }
  else
  {
    timestamp = true;
  }
}
/*Standby mode*/
void ApplicationFunctionSet::ApplicationFunctionSet_Standby(void)
{
  static bool is_ED = true;
  static uint8_t cout = 0;
  if (Application_OwlBotxxx0.Functional_Mode == Standby_mode)
  {
    ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
    if (true == is_ED) //Used to zero yaw raw data(Make sure the car is placed on a stationary surface!)
    {
      static unsigned long timestamp; //acquire timestamp
      if (millis() - timestamp > 20)
      {
        timestamp = millis();
        if (ApplicationFunctionSet_OwlBotLeaveTheGround() /* condition */)
        {
          cout += 1;
        }
        else
        {
          cout = 0;
        }
        if (cout > 10)
        {
          is_ED = false;
          AppMPU6050getdata.MPU6050_calibration();
        }
      }
    }
  }
}

/* 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Begin:CMD
 * Graphical programming and command control module
 $ Elegoo & OwlBot & 2019-09
*/

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_MotorControl_xxx0(uint8_t is_MotorSelection, uint8_t is_MotorDirection, uint8_t is_MotorSpeed)
@ Functional function:  Owl Car motor speed control
@ Input parameters:     uint8_t CMD_is_MotorSelection,  Motor selection  1left motor  2right motor  0both motors
                        uint8_t CMD_is_MotorDirection,  rotation direction selection  1forward  2backward  0stop
                        uint8_t CMD_is_MotorSpeed,      motor speed  0-250
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD mode：N1 command. Car receive the control commands from the APP<motor control command>,perform unidirectional drive of the motor (no time limit: the motor does not receive the time limit when it is running)
    *Take motor control as object-oriented
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_MotorControl_xxx0(void)
{
  static boolean MotorControl = false;
  static uint8_t is_MotorSpeed_A = 0;
  static uint8_t is_MotorSpeed_B = 0;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_MotorControl)
  {
    MotorControl = true;
    if (0 == CMD_is_MotorDirection)
    {
      ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
      return;
    }
    else
    {
      switch (CMD_is_MotorSelection) //motor selection
      {
      case 0:
      {
        is_MotorSpeed_A = CMD_is_MotorSpeed;
        is_MotorSpeed_B = CMD_is_MotorSpeed;
        if (1 == CMD_is_MotorDirection)
        { //turn forward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_just, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else if (2 == CMD_is_MotorDirection)
        { //turn backward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_back, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else
        {
          return;
        }
      }
      break;
      case 1:
      {
        is_MotorSpeed_A = CMD_is_MotorSpeed;
        if (1 == CMD_is_MotorDirection)
        { //turn forward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_void, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_just, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else if (2 == CMD_is_MotorDirection)
        { //turn backward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_void, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_back, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else
        {
          return;
        }
      }
      break;
      case 2:
      {
        is_MotorSpeed_B = CMD_is_MotorSpeed;
        if (1 == CMD_is_MotorDirection)
        { //turn forward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_void, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else if (2 == CMD_is_MotorDirection)
        { //turn backward
          AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_back, /*speed_A*/ is_MotorSpeed_A,
                                                 /*direction_B*/ direction_void, /*speed_B*/ is_MotorSpeed_B,
                                                 /*controlED*/ control_enable); //Motor control
        }
        else
        {
          return;
        }
      }
      break;
      default:
        break;
      }
    }
  }
  else
  {
    if (MotorControl == true)
    {
      MotorControl = false;
      is_MotorSpeed_A = 0;
      is_MotorSpeed_B = 0;
    }
  }
}

static void CMD_CarControl(uint8_t is_CarDirection, uint8_t is_CarSpeed)
{
  switch (is_CarDirection)
  {
  case 1: /*movement direction mode left*/
    ApplicationFunctionSet_OwlBotMotionControl(Left, is_CarSpeed);
    break;
  case 2: /*movement direction mode right*/
    ApplicationFunctionSet_OwlBotMotionControl(Right, is_CarSpeed);
    break;
  case 3: /*movement direction mode forward*/
    ApplicationFunctionSet_OwlBotMotionControl(Forward, is_CarSpeed);
    break;
  case 4: /*movement direction mode backward*/
    ApplicationFunctionSet_OwlBotMotionControl(Backward, is_CarSpeed);
    break;
  default:
    break;
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_CarControlTimeLimit_xxx0(void)
@ Functional function:  Owl Car movement direction and speed control
@ Input parameters:     uint8_t CMD_is_CarDirection,  1（turn left）、2（turn right）、3（forward）、4（backward）
                        uint8_t CMD_is_CarSpeed,      motor speed  0-250
                        uint32_t CMD_is_Timer         execution time
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N2 command. Receive the control commands from the APP,perform movement direction and speed control of the car(Time limit: the motor receives time limit when running)
      *Take movement direction and speed control as object-oriented
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_CarControlTimeLimit_xxx0(void)
{
  // Application_FunctionSet.CMD_is_CarDirection, Application_FunctionSet.CMD_is_CarSpeed, Application_FunctionSet.CMD_is_CarTimer
  static boolean CarControl = false;
  static boolean CarControl_TE = false; //Time stamp
  static boolean CarControl_return = false;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_CarControl_TimeLimit) //enter time-limited control mode
  {
    CarControl = true;
    if (CMD_is_CarTimer != 0) //#1 if the pre-set time is not ... (zero)
    {
      if ((millis() - Application_OwlBotxxx0.CMD_CarControl_Millis) > (CMD_is_CarTimer)) //check the timestamp
      {
        CarControl_TE = true;
        ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);

        Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
        if (CarControl_return == false)
        {

#if _is_print
          Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
          CarControl_return = true;
        }
      }
      else
      {
        CarControl_TE = false; //There is still time left
        CarControl_return = false;
      }
    }
    if (CarControl_TE == false && Car_LeaveTheGround == true)
    {
      CMD_CarControl(CMD_is_CarDirection, CMD_is_CarSpeed);
    }
  }
  else
  {
    if (CarControl == true)
    {
      CarControl_return = false;
      CarControl = false;
      Application_OwlBotxxx0.CMD_CarControl_Millis = 0;
    }
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:  void ApplicationFunctionSet::CMD_CarControlNoTimeLimit_xxx0(void)
@ Functional function:  Owl Car movement direction and speed control
@ Input parameters:     uint8_t CMD_is_CarDirection,  1（turn left）、2（turn right）、3（forward）、4（backward）
                        uint8_t CMD_is_CarSpeed,      motor speed  0-250
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N3 command. Receive the control commands from the APP,perform movement direction and speed control of the car(No time limit: the motor does not receive time limit when running)
      *Take movement direction and speed control as object-oriented
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_CarControlNoTimeLimit_xxx0(void)
{

  static boolean CarControl = false;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_CarControl_NoTimeLimit) //enter no time-limited control mode
  {
    CarControl = true;
    if (Car_LeaveTheGround == true)
    {
      CMD_CarControl(CMD_is_CarDirection, CMD_is_CarSpeed);
    }
  }
  else
  {
    if (CarControl == true)
    {
      CarControl = false;
    }
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:  void ApplicationFunctionSet::CMD_MotorControlSpeed_xxx0(void)
@ Functional function:  Owl Car motor control
@ Input parameters:    uint8_t CMD_is_Speed_L(left motor speed), uint8_t CMD_is_Speed_R(right motor speed)
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N4 command. Receive the control commands from the APP,perform motion control of the motor(No time limit: the motor does not receive time limit when running)
      *Take motor control as object-oriented
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_MotorControlSpeed_xxx0(void)
{
  static boolean MotorControl = false;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_MotorControl_Speed)
  {
    MotorControl = true;
    if (CMD_is_MotorSpeed_L == 0 && CMD_is_MotorSpeed_R == 0)
    {
      ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
    }
    else
    {
      AppMotor.DeviceDriverSet_Motor_control(/*direction_A*/ direction_just, /*speed_A*/ CMD_is_MotorSpeed_R,
                                             /*direction_B*/ direction_just, /*speed_B*/ CMD_is_MotorSpeed_L,
                                             /*controlED*/ control_enable); //Motor control
    }
  }
  else
  {
    if (MotorControl == true)
    {
      MotorControl = false;
    }
  }
}

/*
  N5 command
  CMD command：<servo motor control>
  Pending for upgrade: no processing for now
*/
void ApplicationFunctionSet::CMD_ServoControl_xxx0(void)
{
  if (Application_OwlBotxxx0.Functional_Mode == CMD_ServoControl)
  {
    //Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:  void ApplicationFunctionSet::CMD_VoiceControl_xxx0(void)
@ Functional function:  Owl Car voice control
@ Input parameters:   is_controlAudio, tone frequency
                      is_VoiceTimer    duration
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N6 command. Receive the control commands from the APP,perform control of the sound module(Time-limited: The sound is received at a time when it is running)
    0#：Enter programming mode after time is over
      *Take voice control as object-oriented
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_VoiceControl_xxx0(void)
{
  if (Application_OwlBotxxx0.Functional_Mode == CMD_VoiceControl)
  {
    ApppassiveBuzzer.DeviceDriverSet_passiveBuzzer_controlAudio(CMD_is_controlAudio, CMD_is_VoiceTimer);
    Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
#if _is_print
    Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
  }
}

static void CMD_Lighting(uint8_t is_LightingSequence, int8_t is_LightingColorValue_R, uint8_t is_LightingColorValue_G, uint8_t is_LightingColorValue_B)
{
  switch (is_LightingSequence)
  {
  case 0:
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(NUM_LEDS, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  case 1: /*Left RGB*/
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(3, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  case 2: /*front RGB*/
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(2, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  case 3: /*right RGB*/
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(1, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  case 4: /*back RGB*/
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(0, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  case 5: /*middle RGB*/
    AppRBG_LED.DeviceDriverSet_RBGLED_Color(4, is_LightingColorValue_R, is_LightingColorValue_G, is_LightingColorValue_B);
    break;
  default:
    break;
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_LightingControlTimeLimit_xxx0(void) 
@ Functional function:  Owl Car RGB display
@ Input parameters:     CMD_is_LightingSequence (Left, front, right, back and center)
                        CMD_is_LightingColorValue_R,
                        CMD_is_LightingColorValue_G,
                        CMD_is_LightingColorValue_B,
                        CMD_is_LightingTimer,
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N7 command.
    0# RGB Lighting Control with Time Limitation
    1# enter programming mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_LightingControlTimeLimit_xxx0(void)
{
  static boolean LightingControl = false;
  static boolean LightingControl_TE = false; //Time stamp
  static boolean LightingControl_return = false;

  if (Application_OwlBotxxx0.Functional_Mode == CMD_LightingControl_TimeLimit) //enter time-limited control mode
  {
    LightingControl = true;
    if (CMD_is_LightingTimer != 0) //#1 if the pre-set time is not ... (zero)
    {
      if ((millis() - Application_OwlBotxxx0.CMD_LightingControl_Millis) > (CMD_is_LightingTimer)) //Check the timestamp
      {
        LightingControl_TE = true;
        FastLED.clear(true);
        Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
        if (LightingControl_return == false)
        {

#if _is_print
          Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
          LightingControl_return = true;
        }
      }
      else
      {
        LightingControl_TE = false; //There is still time left
        LightingControl_return = false;
      }
    }
    if (LightingControl_TE == false)
    {
      CMD_Lighting(CMD_is_LightingSequence, CMD_is_LightingColorValue_R, CMD_is_LightingColorValue_G, CMD_is_LightingColorValue_B);
    }
  }
  else
  {
    if (LightingControl == true)
    {
      LightingControl_return = false;
      LightingControl = false;
      Application_OwlBotxxx0.CMD_LightingControl_Millis = 0;
    }
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_LightingControlNoTimeLimit_xxx0(void)
@ Functional function:  Owl Car RGB display
@ Input parameters:     CMD_is_LightingSequence (Left, front, right, back and center)
                        CMD_is_LightingColorValue_R,
                        CMD_is_LightingColorValue_G,
                        CMD_is_LightingColorValue_B
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N8 command.
    0# RGB Lighting Control without Time Limit
    1# enter programming mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_LightingControlNoTimeLimit_xxx0(void)
{
  static boolean LightingControl = false;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_LightingControl_NoTimeLimit) //enter no time-limited control mode
  {
    LightingControl = true;
    CMD_Lighting(CMD_is_LightingSequence, CMD_is_LightingColorValue_R, CMD_is_LightingColorValue_G, CMD_is_LightingColorValue_B);
  }
  else
  {
    if (LightingControl == true)
    {
      LightingControl = false;
    }
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_LEDCustomExpressionControl_xxx0(void)
@ Functional function:  Owl Car LED 8x16 matrix dot pannel expression display
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N9 command.
    0# LED matrix display expression
    1# enter programming mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_LEDCustomExpressionControl_xxx0(void)
{
  if (Application_OwlBotxxx0.Functional_Mode == CMD_ledExpressionControl)
  {
    Apptm1640.TM1640_FullScreenDisaple_led16x8(CMD_is_LEDCustomExpression_arry /*in*/);
    Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
  }
}
/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_LEDNumberDisplayControl_xxx0(void)
@ Functional function:  Owl Car LED 8x16 matrix dot pannel number display
@ Input parameters:     CMD_is_LEDNumber （0--9）
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N10 command
    0# LED matrix digital display
    1# enter programming mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_LEDNumberDisplayControl_xxx0(void)
{
  if (Application_OwlBotxxx0.Functional_Mode == CMD_ledNumberControl)
  {
    if (CMD_is_LEDNumber < 0)
    {
      CMD_is_LEDNumber = 0;
    }
    if (CMD_is_LEDNumber > 9)
    {
      CMD_is_LEDNumber = 9;
    }
    Apptm1640.TM1640_FullScreenDisaple_led16x8(Apptm1640.Display_Number[CMD_is_LEDNumber] /*in*/);
    Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_ClearAllFunctions_xxx0(void)
@ Functional function:  Owl Car clear all functions
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N100/N110 command.
    0# N100 Clear all functions to enter standby mode
    1# N110 Clear all functions and enter programming mode
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_ClearAllFunctions_xxx0(void)
{
  if (Application_OwlBotxxx0.Functional_Mode == CMD_ClearAllFunctions_Standby_mode) // 0# N100 Clear all functions to enter standby mode
  {
    ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
    FastLED.clear(true);
    AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Black);
    Application_OwlBotxxx0.Motion_Control = stop_it;
    Application_OwlBotxxx0.Functional_Mode = Standby_mode;
  }
  if (Application_OwlBotxxx0.Functional_Mode == CMD_ClearAllFunctions_Programming_mode) //1# N110 Clear all functions and enter programming mode
  {
    ApplicationFunctionSet_OwlBotMotionControl(stop_it, 0);
    FastLED.clear(true);
    AppRBG_LED.DeviceDriverSet_RBGLED_xxx(0 /*Duration*/, 5 /*Traversal_Number*/, CRGB::Black);
    Application_OwlBotxxx0.Motion_Control = stop_it;
    Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode;
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_UltrasoundModuleStatus_xxx0(uint8_t is_get)
@ Functional function:  Owl Car return obstacle avoidance status and data to the serial port
@ Input parameters:     is_get （0/1, status/data）
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N21:command
    0# Status/data selection
    1# Data feedback
    2# swicth to programming mode
    The ultrasonic ranging and obstacle avoidance module receives and feeds back the ultrasonic obstacle avoidance status and ranging data according to the control command of APP terminal.
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_UltrasoundModuleStatus_xxx0(uint8_t is_get)
{
  if (1 == is_get) //ultrasonic sensor  is_get Start     true：has obstacle / false: no obstable
  {
    if (true == UltrasoundDetectionStatus)
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_true}");
#endif
    }
    else
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_false}");
#endif
    }
  }
  else if (2 == is_get) //ultrasonic sensor is_get data
  {

    char toString[10];
    sprintf(toString, "%d", UltrasoundData_cm);
    String str = "";
#if _is_print

    Serial.print('{' + CommandSerialNumber + '_' + toString + '}');
#endif
  }
  //2#swicth to programming mode
  Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_TraceModuleStatus_xxx0(uint8_t is_get)
@ Functional function:  Owl Car return line tracking status and data to the serial port
@ Input parameters:     is_get （0/1, L/R）
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N22 command
    0# L/R left IR sensor and right IR sensor selection
    1# Data feedback
    2# swicth to programming mode
    Tracking module receives and feeds back tracing status and data according to the control command of APP terminal
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_TraceModuleStatus_xxx0(uint8_t is_get)
{
  //0# L  select left IR sensor
  if (0 == is_get) /*Get left IR sensor status*/
  {
    // 1# Data feedback
    if (true == TrackingDetectionStatus_L)
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_true}");
#endif
    }
    else
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_false}");
#endif
    }
  }
  //0# M  select middle IR sensor
  else if (1 == is_get) /*Get middle IR sensor status*/
  {
    // 1# Data feedback
	if (true == TrackingDetectionStatus_M)
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_true}");
#endif
    }
    else
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_false}");
#endif
    }
  }
  //0# R  select middle right sensor
  else if (2 == is_get) /*Get right IR sensor status*/
  {
    // 1# Data feedback									  				  
    if (true == TrackingDetectionStatus_R)
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_true}");
#endif
    }
    else
    {
#if _is_print
      Serial.print('{' + CommandSerialNumber + "_false}");
#endif
    }
  }
  //2#swicth to programming mode
  Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode; /*set mode to programming mode<Waiting for the next set of control commands>*/
}

/*
  Mathematical formula: get the relative angle of any coordinate value 
*/
static void getRngle(float x /*in*/, float y /*in*/, float *getRngle /*out*/)
{
  float Rngle = atan2(y, x) / (2 * acos(-1)) * 360;
  if (Rngle < 0)
    Rngle += 360;
  *getRngle = Rngle;
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::CMD_TrajectoryControl_xxx0(void)
@ Functional function:  Owl Car Trajectory Control
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    CMD command：N103 command
    0# Get the relative angle of the motion coordinate value
    1# Calculate the angle offset error value of the plane position
    2# Determine the offset direction of the front and back movement coordinates
    3# Perform car straight movement
    4# swicth to programming mode
    5# Waiting for the next motion coordinate value update
    This part of the program is to deal with APP and PC command control
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::CMD_TrajectoryControl_xxx0(void)
{
  static boolean NextCtrlCycleUp_flag = false;
  static float Trajectory_Record_X = 0; //Base coordinates (virtual dot coordinates)
  static float Trajectory_Record_Y = 0;
  if (Application_OwlBotxxx0.Functional_Mode == CMD_TrajectoryControl)
  {
    if (NextCtrlCycleUp_flag == false) //First coordinate record
    {
      Trajectory_Record_X = CMD_is_TrajectoryControl_axisPlaneData_X; //Base coordinates (update virtual dot coordinates)
      Trajectory_Record_Y = CMD_is_TrajectoryControl_axisPlaneData_Y;
    }
    //Get the latest specified coordinate position value
    float New_Record_X = (CMD_is_TrajectoryControl_axisPlaneData_X); //movement coordinates
    float New_Record_Y = (CMD_is_TrajectoryControl_axisPlaneData_Y);
    float Position_angle_E0;        //The current angle
    static float Position_angle_E1; //Last angle in history
    float Deviation_angle;          //Deviation angle
    int Motion_angle;               //Movement angle
    int DirectionControl = 0;       //Direction control sign
    //0# Get the relative angle of the motion coordinate value
    getRngle(New_Record_X - Trajectory_Record_X /*in*/, New_Record_Y - Trajectory_Record_Y /*in*/, &Position_angle_E0 /*out*/);
    //1 #Calculate the angle offset error value of the plane position
    Deviation_angle = Position_angle_E0 - Position_angle_E1; //Deviation angle<（P-0） - （p-1）:the current value  minus the last value>
    //The direction is centered on Position_angle_E1, split left and right movement control range ±180°
    float LeftAngle = Position_angle_E1 + 180;
    float RightAngle = Position_angle_E1 - 180;

    if (NextCtrlCycleUp_flag == true)
    {
      //2 #Determine the offset direction of the front and back movement coordinates
      if (LeftAngle <= 360) //Position_angle_E1° --------（+360°）Counterclockwise：If the left angle is within the control range？<<<----
      {
        if (Position_angle_E0 > Position_angle_E1 /*current angle is larger than the last angle*/ && Position_angle_E0 < LeftAngle /*current angle is smaller than the control range*/)
        { //Front left movement
          DirectionControl = 1;
          Motion_angle = Deviation_angle;
        }
        else
        { //Front right movement
          if (Deviation_angle > 0)
          {
            DirectionControl = 2;
            int a = (360 - Position_angle_E0 + Position_angle_E1);
            Motion_angle = a;
          }
          else
          {
            DirectionControl = 2;
            Motion_angle = Deviation_angle;
          }
        }
      }
      else if (RightAngle >= 0) //Position_angle_E1° --------（+0°）Clockwise：If the right angle is within the control range？---->>>
      {
        if (Position_angle_E0 < Position_angle_E1 && Position_angle_E0 > RightAngle)
        { //Front right movement
          DirectionControl = 2;
          Motion_angle = Deviation_angle;
        }
        else
        { //Front left movement
          if (Deviation_angle < 0)
          {
            DirectionControl = 1;
            int a = (360 - Position_angle_E1 + Position_angle_E0);
            Motion_angle = a;
          }
          else
          {
            DirectionControl = 1;
            Motion_angle = Deviation_angle;
          }
        }
      }
      Motion_angle = abs(Motion_angle);
      uint16_t Motion_angle_time = (750.0 / 90.0) * Motion_angle; //Change the offset position angle by controlling the motor movement time

      if (2 == DirectionControl) //Front left direction motion control
      {
        ApplicationFunctionSet_OwlBotMotionControl(Left /*in:direction*/, 100 /*in:0 < speed > 250*/);
        delay(Motion_angle_time);
        // Serial.print('{' + CommandSerialNumber + "_ok}");
      }
      else if (1 == DirectionControl) //Front right direction motion control
      {
        ApplicationFunctionSet_OwlBotMotionControl(Right /*in:direction*/, 100 /*in:0 < speed > 250*/);
        delay(Motion_angle_time);
        // Serial.print('{' + CommandSerialNumber + "_ok}");
      }
      //3# Straight movement
      ApplicationFunctionSet_OwlBotMotionControl(Forward /*in:direction*/, 100 /*in:0 < speed > 250*/);
    }
    //4# swicth to programming mode
    Application_OwlBotxxx0.Functional_Mode = CMD_Programming_mode;

    Trajectory_Record_X = New_Record_X; //Record the latest calculated coordinate value and use it on the next control point
    Trajectory_Record_Y = New_Record_Y;
    Position_angle_E1 = Position_angle_E0; //Record this angle value and use it on the next control point
    NextCtrlCycleUp_flag = true;
  }
  else
  {
    if (NextCtrlCycleUp_flag == true)
    {
      if (Application_OwlBotxxx0.Functional_Mode == CMD_ClearAllFunctions_Standby_mode) //Clear all functions: enter standby mode. N100 command
      {
        NextCtrlCycleUp_flag = false;
        Trajectory_Record_X = 0; //Base coordinates (virtual dot coordinates)
        Trajectory_Record_Y = 0;
      }
    }
  }
}

/* 
 * End:CMD
 * Graphical programming and command control module
 $ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_KeyCommand(void)
@ Functional function:  Owl Car acquire button command
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_KeyCommand(void)
{
  uint8_t get_keyValue;
  static uint8_t temp_keyValue = keyValue_Max;
  AppKey.DeviceDriverSet_key_Get(&get_keyValue);

  if (temp_keyValue != get_keyValue)
  {

    temp_keyValue = get_keyValue;
    switch (get_keyValue)
    {
    case /* constant-expression */ 1:
      /* code */
      Application_OwlBotxxx0.Functional_Mode = Standby_mode;
      break;
    case /* constant-expression */ 2:
      /* code */
      Application_OwlBotxxx0.Functional_Mode = TraceBased_mode;
      break;
    case /* constant-expression */ 3:
      /* code */
      Application_OwlBotxxx0.Functional_Mode = ObstacleAvoidance_mode;
      break;
    default:

      break;
    }
  }
}

/*
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@ Function prototype:   void ApplicationFunctionSet::ApplicationFunctionSet_SerialPortDataAnalysis(void)
@ Functional function:  Owl Car Serial data analysis
@ Input parameters:     none
@ Output parameters:    none
@ Other Notes:          This is an ApplicationFunctionSet layer public function <Call the hardware driver layer : DeviceDriverSet_xxx0_H >
    1#Receive serial data stream
    2#Import JsonDocument
    3#Parse and update the value of the control command
$ Elegoo & OwlBot & 2019-09
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
void ApplicationFunctionSet::ApplicationFunctionSet_SerialPortDataAnalysis(void)
{
  uint8_t Rocker_temp;
  static String SerialPortData = "";
  uint8_t c = "";
  //1 #Receive serial data stream
  if (Serial.available() > 0)
  {
    while (c != '}' && Serial.available() > 0)
    {
      // while (Serial.available() == 0)//Forcibly wait for a frame of data to be received
      //   ;
      c = Serial.read();
      SerialPortData += (char)c;
    }
  }
  if (c == '}')
  {
#if _Test_print
    Serial.println(SerialPortData);
#endif

    if (true == SerialPortData.equals("{get_v}"))
    {
      Serial.print("get_v:");
      Serial.println(VoltageData_V);
      SerialPortData = "";
      return;
    }
    if (true == SerialPortData.equals("{version}"))
    {
      Serial.println("Elegoo & OwlBot & 2019-09");
      SerialPortData = "";
      return;
    }
    //2#Import JsonDocument
    StaticJsonDocument<200> doc;                                       //Declare a JsonDocument object
    DeserializationError error = deserializeJson(doc, SerialPortData); //Deserialize JSON data from the serial data buffer
    SerialPortData = "";
    if (!error) //Check if the deserialization is successful
    {
      uint8_t control_mode_N = doc["N"];
      char buf[3];
      uint8_t temp = doc["H"];
      sprintf(buf, "%d", temp);
      CommandSerialNumber = buf; //Get the serial number of the command

      //3#Parse and update the value of the control command
      switch (control_mode_N) 
      {
      case 1: /*<Command：N 1> motor control mode */
        Application_OwlBotxxx0.Functional_Mode = CMD_MotorControl;
        CMD_is_MotorSelection = doc["D1"];
        CMD_is_MotorSpeed = doc["D2"];
        CMD_is_MotorDirection = 1; //The motor rotates forward by default

#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 2:                                                              /*<Command:N 2> */
        Application_OwlBotxxx0.Functional_Mode = CMD_CarControl_TimeLimit; /*Car movement direction and speed control：Time limited mode*/
        CMD_is_CarDirection = doc["D1"];
        CMD_is_CarSpeed = doc["D2"];
        CMD_is_CarTimer = doc["T"];

        Application_OwlBotxxx0.CMD_CarControl_Millis = millis();
#if _is_print
        //Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 3:                                                                /*<Command:N 3> */
        Application_OwlBotxxx0.Functional_Mode = CMD_CarControl_NoTimeLimit; /*Car movement direction and speed control：No time limited mode*/
        CMD_is_CarDirection = doc["D1"];
        CMD_is_CarSpeed = doc["D2"];

#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 4:                                                            /*<Command:N 4> */
        Application_OwlBotxxx0.Functional_Mode = CMD_MotorControl_Speed; /*motor control:Control motor speed mode*/
        CMD_is_MotorSpeed_L = doc["D1"];
        CMD_is_MotorSpeed_R = doc["D2"];
#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 5:                                                      /*<Command:N 5> */
        Application_OwlBotxxx0.Functional_Mode = CMD_ServoControl; /*servo motor control*/
#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 6:                                                      /*<Command:N 6> */
        Application_OwlBotxxx0.Functional_Mode = CMD_VoiceControl; /*Voice control:Time limited mode*/
                                                                   // CMD_is_VoiceName = doc["D1"];
        CMD_is_controlAudio = doc["D1"];
        CMD_is_VoiceTimer = doc["T"];
        // #if _is_print
        // Serial.print('{' + CommandSerialNumber + "_ok}");
        // #endif
        break;

      case 7:                                                                   /*<Command:N 7> */
        Application_OwlBotxxx0.Functional_Mode = CMD_LightingControl_TimeLimit; /*Lighting control:Time limited mode*/
        CMD_is_LightingSequence = doc["D1"];                                    //Lighting (Left, front, right, back and center)
        CMD_is_LightingColorValue_R = doc["D2"];
        CMD_is_LightingColorValue_G = doc["D3"];
        CMD_is_LightingColorValue_B = doc["D4"];
        CMD_is_LightingTimer = doc["T"];
        Application_OwlBotxxx0.CMD_LightingControl_Millis = millis();
#if _is_print
        //Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 8:                                                                     /*<Command:N 8> */
                                                                                  // Serial.print(CommandSerialNumber);
        Application_OwlBotxxx0.Functional_Mode = CMD_LightingControl_NoTimeLimit; /*Lighting control:No time limited mode*/
        CMD_is_LightingSequence = doc["D1"];                                      //Lighting (Left, front, right, back and center)
        CMD_is_LightingColorValue_R = doc["D2"];
        CMD_is_LightingColorValue_G = doc["D3"];
        CMD_is_LightingColorValue_B = doc["D4"];
#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 9:                                                              /*<Command:N 9> */
        Application_OwlBotxxx0.Functional_Mode = CMD_ledExpressionControl; /*LED matrix dot pannel expression display*/
        uint16_t is_arry[8];
        is_arry[0] = doc["D1"];
        is_arry[1] = doc["D2"];
        is_arry[2] = doc["D3"];
        is_arry[3] = doc["D4"];
        is_arry[4] = doc["D5"];
        is_arry[5] = doc["D6"];
        is_arry[6] = doc["D7"];
        is_arry[7] = doc["D8"];

#if _Test_print
        for (int i = 0; i < 8; i++)
        {
          Serial.println(is_arry[i]);
        }
#endif
        {
          /*Convert double byte data to single byte, and move the highest bit to the lowest bit*/
          uint8_t is_byte = 0x00;
          for (int is_true_j = 0; is_true_j < 16; is_true_j++)
          {
            for (int is_true_i = 0; is_true_i < 8; is_true_i++)
            {
              if ((is_arry[is_true_i] << is_true_j) & 0X8000) //Take the highest bit of the double byte, check if this bit is 1?
              {
                is_byte |= (0X01 << is_true_i); //Set the bit to 1
              }
              else
              {
                is_byte &= ~(0X01 << is_true_i); //Set the bit to 0
              }
            }
            CMD_is_LEDCustomExpression_arry[is_true_j] = is_byte; //Update single byte data buffer
            is_byte = 0x00;
          }
        }

#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 10:                                                         /*<Command:N 10> */
        Application_OwlBotxxx0.Functional_Mode = CMD_ledNumberControl; /*LED matrix dot pannel number display*/

        CMD_is_LEDNumber = doc["D1"];
#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 21: /*<Command:N 21>：ultrasonic sensor: detect obstacle distance */
        CMD_UltrasoundModuleStatus_xxx0(doc["D1"]);
#if _is_print
        //Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 22: /*<Command:N 22>：IR sensor：return IR sensor status */
        CMD_TraceModuleStatus_xxx0(doc["D1"]);
#if _is_print
        //Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 23: /*<Command:N 23>：Check if car is lifted up */
        if (true == Car_LeaveTheGround)
        {
#if _is_print
          Serial.print('{' + CommandSerialNumber + "_false}");
#endif
        }
        else if (false == Car_LeaveTheGround)
        {
#if _is_print
          Serial.print('{' + CommandSerialNumber + "_true}");
#endif
        }
        break;
      case 103:                                                         /*<Command:N 103> */
        Application_OwlBotxxx0.Functional_Mode = CMD_TrajectoryControl; /*Trajectory Control*/

        CMD_is_TrajectoryControl_axisPlaneData_X = doc["D1"];
        CMD_is_TrajectoryControl_axisPlaneData_Y = doc["D2"];
#if _is_print
        //Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;
      case 110:                                                                          /*<Command:N 110> */
        Application_OwlBotxxx0.Functional_Mode = CMD_ClearAllFunctions_Programming_mode; /*Clear all function:Enter programming mode*/
        break;
      case 100:                                                                      /*<Command:N 100> */
        Application_OwlBotxxx0.Functional_Mode = CMD_ClearAllFunctions_Standby_mode; /*Clear all function:Enter standby mode*/
        break;

      case 101: /*<Command:N 101> :bluetooth remote to switch the car mode*/
        if (1 == doc["D1"])
        {
          Application_OwlBotxxx0.Functional_Mode = TraceBased_mode;
        }
        else if (2 == doc["D1"])
        {
          Application_OwlBotxxx0.Functional_Mode = ObstacleAvoidance_mode;
        }

#if _is_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 104: /*<Command:N 104> :Tracking sensitivity threshold adjustment control*/

        //TrackingDetection_E = doc["D1"];
        TrackingDetection_S = doc["D1"];

#if _Test_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      case 105: /*<Command:N 105> :FastLED brightness adjustment control command*/
        if (1 == doc["D1"] && (CMD_is_FastLED_setBrightness < 250))
        {
          CMD_is_FastLED_setBrightness += 5;
        }
        else if (2 == doc["D1"] && (CMD_is_FastLED_setBrightness > 0))
        {
          CMD_is_FastLED_setBrightness -= 5;
        }
        FastLED.setBrightness(CMD_is_FastLED_setBrightness);

#if _Test_print
        Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;
      case 102: /*<Command:N 102> :Rocker control mode command*/
        Application_OwlBotxxx0.Functional_Mode = Rocker_mode;
        //uint8_t
        Rocker_temp = doc["D1"];
        //Rocker_CarSpeed = doc["D2"];
        switch (Rocker_temp)
        {
        case 1:
          Application_OwlBotxxx0.Motion_Control = Forward;
          break;
        case 2:
          Application_OwlBotxxx0.Motion_Control = Backward;
          break;
        case 3:
          Application_OwlBotxxx0.Motion_Control = Left;
          break;
        case 4:
          Application_OwlBotxxx0.Motion_Control = Right;
          break;
        case 5:
          Application_OwlBotxxx0.Motion_Control = LeftForward;
          break;
        case 6:
          Application_OwlBotxxx0.Motion_Control = LeftBackward;
          break;
        case 7:
          Application_OwlBotxxx0.Motion_Control = RightForward;
          break;
        case 8:
          Application_OwlBotxxx0.Motion_Control = RightBackward;
          break;
        case 9:
          Application_OwlBotxxx0.Motion_Control = stop_it;
          break;
        default:
          Application_OwlBotxxx0.Motion_Control = stop_it;
          break;
        }
        //ApplicationFunctionSet_OwlBotMotionControl(Application_OwlBotxxx0.Motion_Control /*direction*/, 255 /*speed*/);
#if _is_print
        // Serial.print('{' + CommandSerialNumber + "_ok}");
#endif
        break;

      default:
        break;
      }
    }
    else
    {
    }
  }
}
